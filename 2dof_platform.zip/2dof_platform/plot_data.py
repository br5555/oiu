# Plot data relevant for controller tuning

plot(t,x)
