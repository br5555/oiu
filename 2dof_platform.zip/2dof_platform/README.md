TODO
====

Use numpy arrays for matrices (e.g. singletons).

Integrate with scikit-fuzzy (?) https://github.com/scikit-fuzzy/scikit-fuzzy